# coding:utf-8
from distutils.core import setup
setup(name='strcap',
      version='0.0.0.1',
      author='Luoxin',
      description='Simple extension of string.',
      platforms='Python2.X',
      author_email='luoxin_T_T@outlook.com',
      url='https://github.com/LuoxinY/strcap',
      py_modules=['work01'],
)